//Header
document.querySelector('.navigate-button').addEventListener('click', function() {
    const messageText = "";
    
    document.getElementById('message-text').textContent = messageText;  

    document.getElementById('director-message-section').scrollIntoView({ behavior: 'smooth' });

    console.log('Button was clicked');
});


//Body
document.addEventListener('DOMContentLoaded', function() {
    const schoolLevelImages = document.querySelectorAll('.level img');
    schoolLevelImages.forEach(image => {
        image.addEventListener('mouseover', () => {
            image.style.filter = 'brightness(1.2)'; 
            image.style.transform = 'scale(1.2)';
            image.style.transition = '1s';
        });

        image.addEventListener('mouseout', () => {
            image.style.filter = 'brightness(1)';
            image.style.transform = 'scale(1)';
        });
    });
});


//Footer
document.addEventListener('DOMContentLoaded', function() {
    const footerLinks = document.querySelectorAll('footer a');
    
    footerLinks.forEach(link => {
        link.addEventListener('mouseover', () => {
            link.style.color = '#ff6347';
            link.style.textDecoration = 'underline';
            link.style.transform = 'scale(1.5)';
            link.style.transition = 'transform 0.6s';
        });

        link.addEventListener('mouseout', () => {
            link.style.color = ''; 
            link.style.textDecoration = 'none';
            link.style.transform = 'scale(1)';
        });
    });
});